package com.proyecto.restaurante

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun onEntry(botonEntry: View){
        val entrar = Intent(this,LoginActivity::class.java)
        startActivity(entrar)

    }

    fun onSubs(botonSubs: View){
        val entrar = Intent(this,SubscribeActivity::class.java)
        startActivity(entrar)

    }
}
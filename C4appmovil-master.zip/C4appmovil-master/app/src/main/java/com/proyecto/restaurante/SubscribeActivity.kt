package com.proyecto.restaurante

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast

class SubscribeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_subscribe)
    }

    fun onBack(botonBack: View){
        val atras = Intent(this,MainActivity::class.java)
        startActivity(atras)

    }

    fun onSave(botonSave:View) {
        val intento = Intent(this, MainActivity::class.java)
        startActivity(intento)
        Toast.makeText(applicationContext, "Tlt_Welcome", Toast.LENGTH_LONG).show()
    }
}
package com.proyecto.restaurante

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import android.content.DialogInterface
import android.widget.Toast

class LoginActivity : AppCompatActivity() {
    private var edt_user: EditText?=null
    private var edt_password: EditText?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        edt_user = findViewById(R.id.edt_user)
        edt_password = findViewById(R.id.edt_password)

    }

    fun onBack(botonBack: View){
        val atras = Intent(this,MainActivity::class.java)
        startActivity(atras)
    }

    fun onLogin(botonLogin:View){
        if(edt_user!!.text.toString()=="cliente1"&&edt_password!!.text.toString()=="123"){

                val intentar=Intent(this,MainActivity::class.java)
                startActivity(intentar)
                Toast.makeText(applicationContext,(getString(R.string.Ttl_Welcome)),Toast.LENGTH_LONG).show()
            }
        else{
            var dialog = AlertDialog.Builder(this).setTitle(getString(R.string.Ttl_Error))
                .setMessage(getString(R.string.Txt_Invalid)).create().show()
        }
    }
}